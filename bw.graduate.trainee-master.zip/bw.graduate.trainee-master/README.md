# Graduate Trainee Test

Joining byteworks is amazing and you can trust that you will have an interesting learning curve and a good time. We cannot wait for you to come to one of our TGIFs. Devs here have snippers. We tried using them in our last paintballing game. The good guys gunned down the bad ones that put bugs in our production code base so we are sure we have zero bugs in production. Check us out here

Maybe we can tell you a story. In the early days of Byteworks, the team built http://ngalaba.com.ng. It's a great market directory though. But we really think the look is boring. 


#### Your task

Play around with the redesigning of the home page of  http://ngalaba.com.ng using HTML, CSS, and/or JAVASCRIPT. Just do something to impress us. We know you are a newbie. We just need you to convince us that you are ready to move from zero to hero.


#### Submission

You will be working in teams if you join. So push your code to a git repository and update your profile with the link to your task. First step towards collaboration.

Lest we forget, impress us further with this cat and mouse challenge [here](https://www.hackerrank.com/challenges/cats-and-a-mouse/problem?utm_campaign=challenge-recommendation&utm_medium=email&utm_source=24-hour-campaign)

You can write in any language. Even if you would like to use Qbasic or Fortran. We believe you. Just make sure your repository is public and we can have access to it when you push. If you have any issues, shoot us an email.

Create a GitHub repo containing the solution to this Graduate Trainee test. The repository should be public.
Go to your application in the careers portal (https://careers.byteworks.com.ng), include the link to your GitHub repo and submit.

